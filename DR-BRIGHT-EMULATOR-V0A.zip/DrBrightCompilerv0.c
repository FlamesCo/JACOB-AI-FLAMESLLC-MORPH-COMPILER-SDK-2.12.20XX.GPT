
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main()
{
    char input[2048];
    char output[2048];
    int i;
    
    printf("Welcome to the Dr. Bright Emulator Compiler!\n\n");
    printf("Please enter a command to compile: ");
    scanf("%s", input);
    
    // Convert all letters to uppercase
    for (i = 0; i < strlen(input); i++) {
        input[i] = toupper(input[i]);
    }
    
    // Compile the command
    strcpy(output, "RUN ");
    strcat(output, input);
    
    // Print the compiled command
    printf("\nCompiled command: %s\n", output);
    
    return 0;
} 